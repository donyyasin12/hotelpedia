package com.telyu.reviewhotel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
