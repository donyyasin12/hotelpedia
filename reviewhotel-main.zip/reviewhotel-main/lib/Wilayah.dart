
class Wilayah{
  int kode_pos;
  String place;
  String url_pic;

  Wilayah(this.place,this.url_pic,this.kode_pos);


}